package hibernate;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "clientes")
public class Cliente {
	
	/*
	 * Todos los campos de la tabla cliente
	 */
	// Id
	@Id
	@Column(name = "idcliente")
	private int idcliente;
	
	@Column(name = "nombre")
	private String nombre;
	
	@Column(name = "direccion")
	private String direccion;
	
	@Column(name = "poblacion")
	private String poblacion;
	
	@Column(name = "telefono")
	private String telefono;
	
	@Column(name = "nif")
	private String nif;
	
	// Las ventas de este cliente
	@OneToMany(mappedBy = "cliente")
	private Set<Ventas> ventas;

	// Metodo para buscar ventas
	public Ventas findVenta(int idVenta) {
		for(Ventas v : ventas) {
			if(v.getIdventa() == idVenta)
				return v;
		}
		return null;
	}
	
	// Getters y Setters
	public int getIdcliente() {
		return idcliente;
	}

	public void setIdcliente(int idcliente) {
		this.idcliente = idcliente;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getPoblacion() {
		return poblacion;
	}

	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}
	

	
}
