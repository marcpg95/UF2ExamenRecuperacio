package hibernate;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "productos")
public class Productos {

	/*
	 * Esta clase define la tabla de productos.
	 */
	
	// Atributos de productos
	//Id
	@Id
	@Column(name = "idproducto")
	private int idproducto;
	
	@Column(name = "descripcion")
	private String descripcion;
	
	@Column(name = "stockactual")
	private int stockactual;
	
	@Column(name = "stockminimo")
	private int stockminimo;
	
	@Column(name = "pvp")
	private double pvp;
	
	// Ventas para este producto
	@OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<Ventas> ventas;

	public int getIdproducto() {
		return idproducto;
	}

	public void setIdproducto(int idproducto) {
		this.idproducto = idproducto;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getStockactual() {
		return stockactual;
	}

	public void setStockactual(int stockactual) {
		this.stockactual = stockactual;
	}

	public int getStockminimo() {
		return stockminimo;
	}

	public void setStockminimo(int stockminimo) {
		this.stockminimo = stockminimo;
	}

	public double getPvp() {
		return pvp;
	}

	public void setPvp(double pvp) {
		this.pvp = pvp;
	}
}
