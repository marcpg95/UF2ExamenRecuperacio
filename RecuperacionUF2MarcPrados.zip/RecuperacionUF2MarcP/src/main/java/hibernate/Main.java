package hibernate;

import java.sql.Date;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import jdbc.ConnectionManager;

public class Main {
	
	static Scanner sc = new Scanner(System.in);

	// Metodo que genera un menu y realiza las distintas acciones
	private static boolean menu() {
	
		System.out.println("1 - Insertar venta");
		System.out.println("2 - Modificar venta");
		System.out.println("3 - Eliminar venta");
		System.out.println("4 - Salir");
		int opcion = tryParseInt();

		switch (opcion) {
		case 1:
			insertaVenta();
			break;
		case 2:
			break;
		case 3:
			eliminarVenta();
			break;
		case 4:
			return true;
		default:
			System.out.println("La opcion no esta en la lista");
		}
		return false;

	}
	
	// Metodo que elimina una venta
	private static void eliminarVenta() {
		System.out.println("Introduce el id del cliente a buscar la venta para ser eliminada:");
		int idCliente = tryParseInt();
		// Comprobamos si existe el cliente
		Cliente c = HibernateManager.getClienteFromId(idCliente);
		if(c == null) {
			System.out.println("Ese cliente no existe");
			return;
		}
		
		System.out.println("Introduce el id de la venta a eliminar del cliente escogido");
		int idVenta = tryParseInt();
		// Comprobamos si existe la venta para ese cliente
		Ventas v = c.findVenta(idVenta);
		if(v == null) {
			System.out.println("Esa venta no existe");
			return;
		}
		
		HibernateManager.esborraVenta(idVenta);
	}
	
	// Metodo que inserta una venta en la BBDD
	private static void insertaVenta() {
			boolean next = false;
			int idVenta = 0, idCliente = 0, idProducte = 0, cantidad = 0;
			// Pedimos los datos
			Cliente c = null;
			Productos p = null;
			while (!next) {
				System.out.println("Introduce el ID de la venta:");
				idVenta = tryParseInt();
				if (!HibernateManager.checkIdVenta(idVenta)) {
					next = true;
				} else {
					System.out.println("Ese id de venta ya existe");
				}
			}
			
			next = false;
			while(!next) {
				System.out.println("Introduce el ID del cliente:");
				idCliente = tryParseInt();
				c = HibernateManager.getClienteFromId(idCliente);
				if(c != null) {
					next = true;
				}else {
					System.out.println("Ese cliente no existe");
				}
			}
			
			next = false;
			while(!next) {
				System.out.println("Introduce el ID del producto:");
				idProducte = tryParseInt();
				p = HibernateManager.getProductoFromId(idProducte);
				if(p != null) {
					next = true;
				}else {
					System.out.println("Ese producto no existe");
				}
			}
			
			next = false;
			while(!next) {
				System.out.println("Introduce la cantidad:");
				cantidad = tryParseInt();
				if(cantidad > 0) {
					next = true;
				}else {
					System.out.println("La cantidad no puede ser 0 o menor que 0");
				}
			}
			
			Date dataVenta = new Date(System.currentTimeMillis());
			
			
			// Llamamos al metodo que crea la venta
			HibernateManager.creaVenta(idVenta, c, p, cantidad, dataVenta);

	}

	
	public static void main(String[] args) {
		// Hasta que el usuario no salga, no acaba
		while(!menu());
	}
	
	// Metodo que comprueba si se introduce un entero
	public static int tryParseInt() {
		while (true) {
			try {
				int n = sc.nextInt();
				sc.nextLine();
				return n;
			} catch (InputMismatchException e) {
				System.out.println("Debes introducir un numero entero.");
				sc.nextLine();
			}
		}
	}
	
}
