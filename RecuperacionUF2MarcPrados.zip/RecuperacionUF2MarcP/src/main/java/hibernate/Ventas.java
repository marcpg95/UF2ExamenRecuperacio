package hibernate;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ventas")
public class Ventas {

	/*
	 * Atributos tabla ventas
	 */
	// Id
	@Id
	@Column(name = "idventa")
	private int idventa;
	
	@Column(name = "fechaventa")
	private Date fechaventa;
	
	// foreign key cliente
	@ManyToOne
    @JoinColumn(name="idcliente", nullable=false)
	private Cliente cliente;
	
	// foreign key producto
	@ManyToOne
    @JoinColumn(name="idproducto", nullable=false)
	private Productos producto;
	
	@Column(name = "cantidad")
	private int cantidad;

	// Getters y Setters
	public int getIdventa() {
		return idventa;
	}

	public void setIdventa(int idventa) {
		this.idventa = idventa;
	}

	public Date getFechaventa() {
		return fechaventa;
	}

	public void setFechaventa(Date fechaventa) {
		this.fechaventa = fechaventa;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Productos getProducto() {
		return producto;
	}

	public void setProducto(Productos producto) {
		this.producto = producto;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}
	
	
	
}
