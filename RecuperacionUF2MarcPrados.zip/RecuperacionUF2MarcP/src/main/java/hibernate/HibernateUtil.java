package hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	// Inicializamos la sessionFactory
		private static SessionFactory sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
		
		/*
		 * Getter de la sessionFactory
		 */
		public static SessionFactory getSessionFactory() {				
			return sessionFactory;
		}
		
		/*
		 * Cierre de la sessionFactory
		 */
		public static void closeFactory() {
			sessionFactory.close();
		}
}
