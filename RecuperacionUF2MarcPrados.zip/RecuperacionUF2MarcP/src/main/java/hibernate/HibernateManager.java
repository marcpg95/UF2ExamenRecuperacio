package hibernate;

import java.sql.Date;
import java.util.ArrayList;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class HibernateManager {

	// Inicializamos la sesion
	private static Session session = HibernateUtil.getSessionFactory().openSession();
	
	// Metodo que crea una venta con lo que se le pase por parametro:
	public static Ventas creaVenta(int idVenta, Cliente cliente, Productos producto, int cantidad, Date fechaVenta){
		Transaction t = session.beginTransaction();
		Ventas v = new Ventas();
		v.setIdventa(idVenta);
		v.setFechaventa(fechaVenta);
		v.setCantidad(cantidad);
		v.setCliente(cliente);
		v.setProducto(producto);
		v = session.get(Ventas.class, session.save(v));
		t.commit();
		return v;
	}
	
	
	// Recogemos un producto teniendo su Id
	public static Productos getProductoFromId(int id) {
		ArrayList<Productos> aLP = obtieneObjetos(Productos.class);
		for(Productos p : aLP) {
			if(p.getIdproducto() == id)
				return p;
		}		
		return null;
	}
	
	// Recogemos un cliente teniendo su Id
	public static Cliente getClienteFromId(int id) {
		ArrayList<Cliente> aLC = obtieneObjetos(Cliente.class);
		for(Cliente c : aLC) {
			if(c.getIdcliente() == id)
				return c;
		}		
		return null;
	}
	
	// Comprobamos si el ID de una venta esta disponible
	public static boolean checkIdVenta(int id) {
		ArrayList<Ventas> aLV = obtieneObjetos(Ventas.class);
		for(Ventas v : aLV) {
			if(v.getIdventa() == id)
				return true;
		}		
		return false;
	}
	
	
	// Eliminamos una venta pasandole el id
	public static void esborraVenta(int idVenta) {
		Ventas v = session.get(Ventas.class, idVenta);
		if(v != null) {
			Transaction trx = session.beginTransaction();
			session.remove(v);
			trx.commit();
		}else {
			System.out.println("Error! No se ha encontrado la venta!");
		}
	}
	
	// Obtenemos las instancias de una clase especifica
	public static <T>ArrayList<T> obtieneObjetos(Class<T> classType) {
		Query q = session.createQuery("from " + classType.getName());
		return (ArrayList<T>) q.getResultList();
	}
	
}
