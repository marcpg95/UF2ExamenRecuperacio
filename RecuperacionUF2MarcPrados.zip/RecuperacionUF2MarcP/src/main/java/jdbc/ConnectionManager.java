package jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ConnectionManager implements ConnectionInterface {
	private static Connection conn;
	
	public static void initialize() throws ClassNotFoundException, SQLException {
		Class.forName(DRIVER);
		conn = DriverManager.getConnection(CONNSTRING, USER, PASSWORD);
	}
	
	public static Connection getConnection() {
		return conn;
	}
	
	public static void insertaDatos() throws SQLException {
		String insertClientes = "INSERT INTO clientes VALUES (1, 'pepe', 'calle falsa', 'cornella', '698765764', '33876564f'),(2, 'rafa', 'calle valencia', 'barcelona', '657876987', '64765434O')";
		String insertProductos = "INSERT INTO productos VALUES (1, 'silla de masajes', 4, 3, 129.99),(2, 'mesa de terraza', 2, 1, 85.49),(3, 'hamaca', 6, 4, 79.99)";
		String insertVentas = "INSERT INTO ventas VALUES (1, '2020-05-01', 1, 1, 1), (2, '2020-05-11', 1, 3, 2),(3, '2020-05-12', 1, 3, 1),(4, '2020-05-21', 2, 1, 2),(5, '2020-05-22', 2, 2, 1),(6, '2020-05-30', 2, 3, 2)";
		ConnectionManager.getConnection().createStatement().executeUpdate(insertClientes);
		ConnectionManager.getConnection().createStatement().executeUpdate(insertProductos);
		ConnectionManager.getConnection().createStatement().executeUpdate(insertVentas);
	}

	public static boolean revisaTablasVacias() throws SQLException {
		String select = "SELECT * FROM clientes";
		ResultSet rs = ConnectionManager.getConnection().createStatement().executeQuery(select);
		if (rs.next())
			return false;
		return true;
	}
	
	public static boolean idVentaDisponible(int idVenta) throws SQLException {
		String select = "SELECT * FROM ventas WHERE idventa = " + idVenta;
		ResultSet rs = getConnection().createStatement().executeQuery(select);
		if(rs.next()) 
			return false;
		return true;
	}
	
	public static boolean clienteExiste(int idCliente) throws SQLException {
		String select = "SELECT * FROM clientes WHERE idcliente = " + idCliente;
		ResultSet rs = getConnection().createStatement().executeQuery(select);
		if(rs.next()) 
			return true;
		return false;
	}
	
	public static boolean productoExiste(int idProducto) throws SQLException {
		String select = "SELECT * FROM productos WHERE idproducto = " + idProducto;
		ResultSet rs = getConnection().createStatement().executeQuery(select);
		if(rs.next()) 
			return true;
		return false;
	}
	
	public static void insertaVenta(int idVenta, int idCliente, int idProducto, int cantidad, Date fechaVenta) throws SQLException {
		String insert = "INSERT INTO ventas VALUES (?,?,?,?,?)";
		PreparedStatement pstmnt = getConnection().prepareStatement(insert);
		pstmnt.setInt(1, idVenta);
		pstmnt.setDate(2, fechaVenta);
		pstmnt.setInt(3, idCliente);
		pstmnt.setInt(4, idProducto);
		pstmnt.setInt(5,  cantidad);
		pstmnt.executeUpdate();
	}
}
