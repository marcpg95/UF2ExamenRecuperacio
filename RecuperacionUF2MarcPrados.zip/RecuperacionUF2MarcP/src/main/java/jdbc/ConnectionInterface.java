package jdbc;

public interface ConnectionInterface {
	String HOST = "localhost";
	String USER = "root";
	String PASSWORD = "";
	String PORT = "3306";
	String DATABASE = "clientes_uf2";
	String DRIVER = "com.mysql.cj.jdbc.Driver";
	String CONNSTRING = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE;
}
